//
//  DetailsViewController.h
//  RssDemo
//
//  Created by nagaranik on 12/2/19.
//  Copyright © 2019 nagaranik. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomSpinnerObject.h"
#import <WebKit/WebKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DetailsViewController : UIViewController
{
    WKWebView *webView;
    CustomSpinnerObject *customProcessionViewObject;
}
@property(nonatomic,retain)NSString *detailsString;
@property(nonatomic,retain)NSString *titleString;


@end

NS_ASSUME_NONNULL_END
