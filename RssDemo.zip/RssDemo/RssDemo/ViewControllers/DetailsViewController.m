//
//  DetailsViewController.m
//  RssDemo
//
//  Created by nagaranik on 12/2/19.
//  Copyright © 2019 nagaranik. All rights reserved.
//

#import "DetailsViewController.h"
#import <WebKit/WebKit.h>

@interface DetailsViewController ()<WKNavigationDelegate>

@end

@implementation DetailsViewController
@synthesize  detailsString,titleString;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor =[UIColor blueColor];
    
    detailsString = [detailsString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    detailsString = [detailsString substringWithRange:NSMakeRange(0, [detailsString length] - 2)];
    
    self.navigationItem.title = titleString;
    
    UIButton *webViewBackBTn = [[UIButton alloc]initWithFrame:CGRectMake(0, 80, 150, 40)];
    [webViewBackBTn setTitle:@"WebView Back" forState:UIControlStateNormal];
    [webViewBackBTn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [webViewBackBTn addTarget:self action:@selector(webviewBack) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:webViewBackBTn];
    
    WKWebViewConfiguration *theConfiguration = [[WKWebViewConfiguration alloc] init];
    webView = [[WKWebView alloc] initWithFrame:CGRectMake(0, 120, self.view.frame.size.width , self.view.frame.size.height - 100) configuration:theConfiguration];
    
    webView.navigationDelegate = self;
    
    NSURL *nsurl=[NSURL URLWithString:detailsString];
    NSURLRequest *nsrequest=[NSURLRequest requestWithURL:nsurl];
    
    [webView loadRequest:nsrequest];
    webView.backgroundColor = [UIColor blueColor];
    [self.view addSubview:webView];
    webView.translatesAutoresizingMaskIntoConstraints = false;
    
    customProcessionViewObject = [[CustomSpinnerObject alloc]initWithFrame:self.view.bounds];
    customProcessionViewObject.backgroundColor = [UIColor clearColor];
    [self.view addSubview:customProcessionViewObject];
    
    [customProcessionViewObject  startSpinner];
    
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self updateViewConstraints];
    // Do any additional setup after loading the view.
}

-(void)webviewBack{
    [webView goBack];
    
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
}

-(void)updateViewConstraints
{
    [super updateViewConstraints];
    
    
    NSLayoutConstraint *webViewTrailingConstraint = [NSLayoutConstraint constraintWithItem:webView attribute:NSLayoutAttributeTrailing relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeTrailing multiplier:1.0f constant:0];
    
    NSLayoutConstraint *webViewLeadingCosntraint = [NSLayoutConstraint constraintWithItem:webView attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeading multiplier:1.0f constant:0];
    
    NSLayoutConstraint *webViewBottomConstraint = [NSLayoutConstraint constraintWithItem:webView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeBottom multiplier:1.0f constant:10];
    
    NSLayoutConstraint *webViewTopConstraint = [NSLayoutConstraint constraintWithItem:webView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeTop multiplier:1.0f constant:120];
    
    [self.view addConstraints:@[webViewTopConstraint,webViewBottomConstraint,webViewLeadingCosntraint,webViewTrailingConstraint]];
    
    
}

-(void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation
{
    
}
- (void)webView:(WKWebView *)webView didCommitNavigation:(WKNavigation *)navigation {
    
}

- (void)webView:(WKWebView *)webView didFailNavigation:(WKNavigation *)navigation withError:(NSError *)error {
    
}

- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(WKNavigation *)navigation withError:(NSError *)error {
    [customProcessionViewObject stopSpinner];
    [customProcessionViewObject removeFromSuperview];
    NSLog(@"fali");
    if (error.code == -1009)
    {
        UIAlertController * alertvc = [UIAlertController alertControllerWithTitle: @ "Alert"
                                                                          message: @"Check Internet connection\n Try again" preferredStyle: UIAlertControllerStyleAlert
                                       ];
        UIAlertAction * action = [UIAlertAction actionWithTitle: @ "Ok"
                                                          style: UIAlertActionStyleDefault handler: ^ (UIAlertAction * _Nonnull action) {
                                                              NSLog(@ "Dismiss Tapped");
                                                          }
                                  ];
        [alertvc addAction: action];
        [self presentViewController: alertvc animated: true completion: nil];
    }
    else
    {
        UIAlertController * alertvc = [UIAlertController alertControllerWithTitle: @ "Alert"
                                                                          message: @"Server error" preferredStyle: UIAlertControllerStyleAlert
                                       ];
        UIAlertAction * action = [UIAlertAction actionWithTitle: @ "Ok"
                                                          style: UIAlertActionStyleDefault handler: ^ (UIAlertAction * _Nonnull action) {
                                                              NSLog(@ "Dismiss Tapped");
                                                          }
                                  ];
        [alertvc addAction: action];
        [self presentViewController: alertvc animated: true completion: nil];
        
    }
    
    
}

- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation {
    
    [customProcessionViewObject stopSpinner];
    [customProcessionViewObject removeFromSuperview];
}

- (void)webView:(WKWebView *)webView didReceiveServerRedirectForProvisionalNavigation:(WKNavigation *)navigation {
    
}

- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler {
    if (navigationAction.navigationType == UIWebViewNavigationTypeLinkClicked) {
        
    }
    decisionHandler(WKNavigationActionPolicyAllow);
}

- (void)webView:(WKWebView *)webView decidePolicyForNavigationResponse:(WKNavigationResponse *)navigationResponse decisionHandler:(void (^)(WKNavigationResponsePolicy))decisionHandler {
    
    decisionHandler(WKNavigationResponsePolicyAllow);
}

- (void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator
{
    [super viewWillTransitionToSize:size
          withTransitionCoordinator:coordinator];
    
    [coordinator animateAlongsideTransition:^(id<UIViewControllerTransitionCoordinatorContext> context)
     {
         
         [self updateViewConstraints];
     }
                                 completion:^(id<UIViewControllerTransitionCoordinatorContext> context)
     {
     }];
    
    
}
@end
