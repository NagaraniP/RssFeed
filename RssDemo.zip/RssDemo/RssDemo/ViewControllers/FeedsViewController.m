//
//  FeedsViewController.m
//  RssDemo
//
//  Created by nagaranik on 12/1/19.
//  Copyright © 2019 nagaranik. All rights reserved.
//

#import "FeedsViewController.h"
#import "RssListViewModelObject.h"
#import "DetailsViewController.h"
#import "CustomCollectionViewCell.h"

static NSString *const RSSFeedURL = @"https://www.personalcapital.com/blog/feed/";

@interface FeedsViewController ()<FeedsDelegate,UICollectionViewDelegate,UICollectionViewDataSource>

@end


@implementation FeedsViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor blueColor];
    self.navigationItem.title = @"Feeds";
    
    feeds = [[NSMutableArray alloc] init];
    
    refreshButton = [[UIBarButtonItem alloc]
                     initWithTitle:@"Refresh"
                     style:UIBarButtonItemStylePlain
                     target:self
                     action:@selector(refresh)];
    self.navigationItem.rightBarButtonItem = refreshButton;
    /** Contentview design **/
    contentView = [[UIView alloc]initWithFrame:CGRectMake(0, 60, self.view.frame.size.width, 280)];
    [contentView setTranslatesAutoresizingMaskIntoConstraints:NO];
    [self.view addSubview:contentView];
    /** Imageview design ***/
    articleImage = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 190)];
    [articleImage setTranslatesAutoresizingMaskIntoConstraints:NO];
    [contentView addSubview:articleImage];
    
    /*** Content layout constraints ***/
    NSLayoutConstraint *contentTrailingConstraint = [NSLayoutConstraint constraintWithItem:contentView attribute:NSLayoutAttributeTrailing relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeTrailing multiplier:1.0f constant:0];
    
    NSLayoutConstraint *contentLeadingConstraint = [NSLayoutConstraint constraintWithItem:contentView attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeading multiplier:1.0f constant:0];
    [self.view addConstraints:@[contentTrailingConstraint,contentLeadingConstraint]];
    
    NSLayoutConstraint *mainImageTrailingConstraint = [NSLayoutConstraint constraintWithItem:articleImage attribute:NSLayoutAttributeTrailing relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeTrailing multiplier:1.0f constant:0];
    
    NSLayoutConstraint *mainImageLeadingConstraint = [NSLayoutConstraint constraintWithItem:articleImage attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeading multiplier:1.0f constant:0];
    
    [self.view addConstraints:@[mainImageLeadingConstraint,mainImageTrailingConstraint]];
    
    /** Designing UIlabel **/
    articleTitle = [[UILabel alloc]initWithFrame:CGRectMake(0, 190, self.view.frame.size.width, 50)];
    articleTitle.backgroundColor = [UIColor clearColor];
    articleTitle.font = [UIFont systemFontOfSize:18];
    articleTitle.numberOfLines = 0;
    articleTitle.textColor = [UIColor whiteColor];
    [articleTitle setTextAlignment:NSTextAlignmentLeft];
    [contentView addSubview:articleTitle];
    [articleTitle setTranslatesAutoresizingMaskIntoConstraints:NO];
    
    /** Label contrainst ***/
    NSLayoutConstraint *titleTrailingConstraint = [NSLayoutConstraint constraintWithItem:articleTitle attribute:NSLayoutAttributeTrailing relatedBy:NSLayoutRelationEqual toItem:contentView attribute:NSLayoutAttributeTrailing multiplier:1.0f constant:0];
    
    NSLayoutConstraint *titleLeadingConstraint = [NSLayoutConstraint constraintWithItem:articleTitle attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:contentView attribute:NSLayoutAttributeLeading multiplier:1.0f constant:0];
    
    [contentView addConstraints:@[titleTrailingConstraint,titleLeadingConstraint]];
    
    /*** Description label design ***/
    articleDes = [[UILabel alloc]initWithFrame:CGRectMake(0, 240, self.view.frame.size.width, 40)];
    articleDes.font = [UIFont systemFontOfSize:16];
    articleDes.numberOfLines = 2;
    articleDes.textColor = [UIColor whiteColor];
    [articleDes setTextAlignment:NSTextAlignmentLeft];
    [contentView addSubview:articleDes];
    [articleDes setTranslatesAutoresizingMaskIntoConstraints:NO];
    
    /** Descrip label constraints ***/
    NSLayoutConstraint *desTrailingConstraint = [NSLayoutConstraint constraintWithItem:articleDes attribute:NSLayoutAttributeTrailing relatedBy:NSLayoutRelationEqual toItem:contentView attribute:NSLayoutAttributeTrailing multiplier:1.0f constant:0];
    
    NSLayoutConstraint *desLeadingConstraint = [NSLayoutConstraint constraintWithItem:articleDes attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:contentView attribute:NSLayoutAttributeLeading multiplier:1.0f constant:0];
    
    [contentView addConstraints:@[desTrailingConstraint,desLeadingConstraint]];
    
    /** Adding gesture to view to navigate to details **/
    UITapGestureRecognizer *singleTap =
    [[UITapGestureRecognizer alloc] initWithTarget:self
                                            action:@selector(showDetails)];
    [contentView addGestureRecognizer:singleTap];
    
    /** Collection layout design and contrainst **/
    layout=[[UICollectionViewFlowLayout alloc] init];
    _collectionView=[[UICollectionView alloc] initWithFrame:CGRectMake(0, 340, self.view.frame.size.width, self.view.frame.size.height - 340) collectionViewLayout:layout];
    _collectionView.translatesAutoresizingMaskIntoConstraints = false;
    [_collectionView setDataSource:self];
    [_collectionView setDelegate:self];
    [_collectionView registerClass:[CustomCollectionViewCell class] forCellWithReuseIdentifier:@"cellIdentifier"];
    [_collectionView setBackgroundColor:[UIColor blueColor]];
    [self.view addSubview:_collectionView];
    
    
    [self updateViewConstraints];
    NSLayoutConstraint *collectionViewTrailingConstraint = [NSLayoutConstraint constraintWithItem:_collectionView attribute:NSLayoutAttributeTrailing relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeTrailing multiplier:1.0f constant:0];
    
    NSLayoutConstraint *collectionViewLeadingConstraint = [NSLayoutConstraint constraintWithItem:_collectionView attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeading multiplier:1.0f constant:0];
    collectionViewTopConstraint = [NSLayoutConstraint constraintWithItem:_collectionView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeTop multiplier:1.0f constant:[self calculatepercentage:UIScreen.mainScreen.bounds.size.height percentage:48]];
    
    collectionViewBottomConstraint = [NSLayoutConstraint constraintWithItem:_collectionView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeBottom multiplier:1.0f constant:20];
    
    [self.view addConstraints:@[collectionViewTrailingConstraint,collectionViewLeadingConstraint,collectionViewTopConstraint,collectionViewBottomConstraint]];
    
    
    /** Spinner allocation to start and stop***/
    customProcessionViewObject = [[CustomSpinnerObject alloc]initWithFrame:self.view.bounds];
    customProcessionViewObject.backgroundColor = [UIColor clearColor];
    [self.view addSubview:customProcessionViewObject];
    
    [customProcessionViewObject  startSpinner];
    
    RssListViewModelObject *viewModelObj = [[RssListViewModelObject alloc]init];
    viewModelObj.feedDelegate = self;
    [viewModelObj sendRequestData:RSSFeedURL];
    viewModelObj = nil;
    // Do any additional setup after loading the view.
}

/** Navigating to details screen to show selected article link **/
-(void)showDetails{
    NSString *string = [feeds[0] objectForKey: @"link"];
    DetailsViewController *vc = [[DetailsViewController alloc]init];
    vc.detailsString = string;
    vc.titleString =  [feeds[0] objectForKey: @"title"];
    [self.navigationController pushViewController:vc animated:YES];
}

/*** To refresh Rss Feed URL ***/
-(void)refresh
{
    customProcessionViewObject = [[CustomSpinnerObject alloc]initWithFrame:self.view.bounds];
    customProcessionViewObject.backgroundColor = [UIColor clearColor];
    [self.view addSubview:customProcessionViewObject];
    [customProcessionViewObject startSpinner];
    [refreshButton setEnabled:false];
    RssListViewModelObject *viewModelObj = [[RssListViewModelObject alloc]init];
    viewModelObj.feedDelegate = self;
    [viewModelObj sendRequestData:RSSFeedURL];
    viewModelObj = nil;
}


-(void)sendFeeds:(NSMutableArray *)array feedTitle:(NSString *)title
{
    feeds = array;
    
    dispatch_async(dispatch_get_main_queue(), ^{
        self.navigationItem.title = title;
        [self->articleImage setImage:[self getImage:[[self->feeds objectAtIndex:0] objectForKey:@"media:content"] ] ];
        [self->articleTitle setText:[[self->feeds objectAtIndex:0] objectForKey:@"title"]];
        [self->articleDes setText:[[self->feeds objectAtIndex:0] objectForKey:@"description"]];
        [self->_collectionView reloadData];
        [self->_collectionView performBatchUpdates:^{}
                                        completion:^(BOOL finished) {
                                            /// collection-view finished reload
                                            [self->customProcessionViewObject stopSpinner];
                                            [self->customProcessionViewObject removeFromSuperview];
                                            [self->refreshButton setEnabled:true];
                                        }];
    });
}
/*** Showing alert based on responce error code ***/
-(void)showAlertMessage:(NSString*)message
{
    
    UIAlertController * alertvc = [UIAlertController alertControllerWithTitle: @ "Alert"
                                                                      message: message preferredStyle: UIAlertControllerStyleAlert
                                   ];
    UIAlertAction * action = [UIAlertAction actionWithTitle: @ "Ok"
                                                      style: UIAlertActionStyleDefault handler: ^ (UIAlertAction * _Nonnull action) {
                                                          [self->customProcessionViewObject stopSpinner];
                                                          [self->customProcessionViewObject removeFromSuperview];
                                                          [self->refreshButton setEnabled:true];
                                                          NSLog(@ "Dismiss Tapped");
                                                      }
                              ];
    [alertvc addAction: action];
    [self presentViewController: alertvc animated: true completion: nil];
    
}

-(UIImage*)getImage:(NSString*)urlStr
{
    NSURL *aURL = [NSURL URLWithString:urlStr];
    UIImage *aImage = [UIImage imageWithData:[NSData dataWithContentsOfURL:aURL]];
    return  aImage;
}
/** Calculate layout constrainst based on percenatge ***/
-(CGFloat)calculatepercentage:(CGFloat)value percentage:(CGFloat)pValue
{
    return  (value * pValue)/100;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return feeds.count-1;
}

/** Dislaying data in cell ***/
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    CustomCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cellIdentifier" forIndexPath:indexPath];
    cell.layer.shouldRasterize = YES;
    cell.layer.rasterizationScale = [UIScreen mainScreen].scale;
    [cell layoutSubviews];
    if (cell == nil) {
        cell = [[CustomCollectionViewCell alloc] init];
    }
    int index = (int)(indexPath.row + 1);
    [[cell articleTitleLabel] setText:[[feeds objectAtIndex:index] objectForKey:@"title"]];
    [[cell articleImage] setImage:[self getImage:[[feeds objectAtIndex:index] objectForKey:@"media:content"] ]];
    
    
    return cell;
}
/** Naviagting to details screen to show selected article link **/
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    NSString *string = [feeds[indexPath.row + 1] objectForKey: @"link"];
    
    DetailsViewController *vc = [[DetailsViewController alloc]init];
    vc.detailsString = string;
    vc.titleString =  [feeds[indexPath.row + 1] objectForKey: @"title"];
    [self.navigationController pushViewController:vc animated:YES];
}
/** To show number of cells in row based on device iphone /ipad***/
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    
    CGFloat padding = 20;
    CGFloat cellSize = collectionView.frame.size.width - padding;
    UIDevice* thisDevice = [UIDevice currentDevice];
    if(thisDevice.userInterfaceIdiom == UIUserInterfaceIdiomPad)
    {
        padding = 30;
        cellSize = collectionView.frame.size.width - padding;
        return CGSizeMake(cellSize / 3, cellSize / 3);
    }
    return CGSizeMake(cellSize / 2, (cellSize / 2) );
}

/** Updating constrainst based on device orientaion **/
-(void)updateViewConstraints{
    [super updateViewConstraints];
    
    
    contentTopConstraint = [NSLayoutConstraint constraintWithItem:self->contentView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeTop multiplier:1.0f constant:[self calculatepercentage:UIScreen.mainScreen.bounds.size.height percentage:8.1]];
    
    contentHieghtConstraint = [NSLayoutConstraint constraintWithItem:self->contentView attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.0 constant:[self calculatepercentage:UIScreen.mainScreen.bounds.size.height percentage:40]];
    
    mainImageHieghtConstraint = [NSLayoutConstraint constraintWithItem:self->articleImage attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.0 constant:[self calculatepercentage:UIScreen.mainScreen.bounds.size.height percentage:25.5]];
    
    
    mainImageTopConstraint = [NSLayoutConstraint constraintWithItem:self->articleImage attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeTop multiplier:1.0f constant:[self calculatepercentage:UIScreen.mainScreen.bounds.size.height percentage:8.1]];
    
    
    titleHieghtConstraint = [NSLayoutConstraint constraintWithItem:self->articleTitle attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.0 constant:[self calculatepercentage:UIScreen.mainScreen.bounds.size.height percentage:7.3]];
    
    
    titleTopConstraint = [NSLayoutConstraint constraintWithItem:self->articleTitle attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self->contentView attribute:NSLayoutAttributeTop multiplier:1.0f constant:[self calculatepercentage:UIScreen.mainScreen.bounds.size.height percentage:25.5]];
    
    desHieghtConstraint = [NSLayoutConstraint constraintWithItem:self->articleDes attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.0 constant:[self calculatepercentage:UIScreen.mainScreen.bounds.size.height percentage:7]];
    
    
    desTopConstraint = [NSLayoutConstraint constraintWithItem:self->articleDes attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self->contentView attribute:NSLayoutAttributeTop multiplier:1.0f constant:[self calculatepercentage:UIScreen.mainScreen.bounds.size.height percentage:32]];
    
    [self.view addConstraint:titleTopConstraint];
    [self.view addConstraint:desTopConstraint];
    [self.view addConstraint:contentTopConstraint];
    [self.view addConstraint:mainImageTopConstraint];
    
    
    [articleTitle addConstraint:titleHieghtConstraint];
    [articleDes addConstraint:desHieghtConstraint];
    [contentView addConstraint:contentHieghtConstraint];
    [articleImage addConstraint:mainImageHieghtConstraint];
    
}
/*** Adding collection view constraints **/
-(void)addCollectionViewConstraints
{
    NSLayoutConstraint *collectionViewTrailingConstraint = [NSLayoutConstraint constraintWithItem:_collectionView attribute:NSLayoutAttributeTrailing relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeTrailing multiplier:1.0f constant:0];
    NSLayoutConstraint *collectionViewLeadingConstraint = [NSLayoutConstraint constraintWithItem:_collectionView attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeading multiplier:1.0f constant:0];
    collectionViewTopConstraint = [NSLayoutConstraint constraintWithItem:_collectionView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeTop multiplier:1.0f constant:[self calculatepercentage:UIScreen.mainScreen.bounds.size.height percentage:48]];
    
    NSLayoutConstraint *collectionViewBottomConstraint = [NSLayoutConstraint constraintWithItem:_collectionView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeBottom multiplier:1.0f constant:10];
    
    [self.view addConstraints:@[collectionViewTrailingConstraint,collectionViewLeadingConstraint,collectionViewTopConstraint,collectionViewBottomConstraint]];
    
}
/** Remove and update constraints based on device orientation **/
-(void)removeConstraints
{
    [articleTitle removeConstraint:titleHieghtConstraint];
    [self.view removeConstraint:titleTopConstraint];
    [articleDes removeConstraint:desHieghtConstraint];
    [self.view removeConstraint:desTopConstraint];
    [contentView removeConstraint:contentHieghtConstraint];
    [self.view removeConstraint:contentTopConstraint];
    [self.view removeConstraint:mainImageTopConstraint];
    [articleImage removeConstraint:mainImageHieghtConstraint];
    [self.view removeConstraint:collectionViewTopConstraint];
    [self.view removeConstraint:collectionViewBottomConstraint];
}
/** Device orientation/Transition **/
- (void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator
{
    [super viewWillTransitionToSize:size
          withTransitionCoordinator:coordinator];
    
    [coordinator animateAlongsideTransition:^(id<UIViewControllerTransitionCoordinatorContext> context)
     {
         [self removeConstraints];
         [self updateViewConstraints];
         [self addCollectionViewConstraints];
     }
                                 completion:^(id<UIViewControllerTransitionCoordinatorContext> context)
     
     {
         [self->_collectionView reloadData];
     }];
    
    
}

/** Spacing ***/
- (UIEdgeInsets)collectionView: (UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    
    return UIEdgeInsetsMake(0,5,0,5);
    
}


-(void)dealloc
{
}


@end
