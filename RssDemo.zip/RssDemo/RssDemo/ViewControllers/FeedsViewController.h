//
//  FeedsViewController.h
//  RssDemo
//
//  Created by nagaranik on 12/1/19.
//  Copyright © 2019 nagaranik. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomSpinnerObject.h"

NS_ASSUME_NONNULL_BEGIN

@interface FeedsViewController : UIViewController
{
    UICollectionView *_collectionView;
    UIBarButtonItem *refreshButton;
    NSMutableArray *feeds;
    UIImageView *articleImage;
    UILabel *articleTitle;
    UILabel *articleDes;
    UIButton *button;
    CustomSpinnerObject *customProcessionViewObject;
    UIView *contentView;
    UICollectionViewFlowLayout *layout;
    NSLayoutConstraint *collectionViewTopConstraint;
    NSLayoutConstraint *contentHieghtConstraint;
    NSLayoutConstraint *contentTopConstraint;
   NSLayoutConstraint *mainImageHieghtConstraint;
    NSLayoutConstraint *mainImageTopConstraint;
    NSLayoutConstraint *titleHieghtConstraint ;
    NSLayoutConstraint *titleTopConstraint;
    NSLayoutConstraint *desHieghtConstraint ;
    NSLayoutConstraint *desTopConstraint ;
    
    NSLayoutConstraint *collectionViewBottomConstraint;
}
@end

NS_ASSUME_NONNULL_END
