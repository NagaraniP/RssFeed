//
//  NetworkObject.h
//  RssDemo
//
//  Created by nagaranik on 12/1/19.
//  Copyright © 2019 nagaranik. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
@protocol NetworkDelgate <NSObject>

- (void)sendData:(NSData *)dataObj;
-(void)error:(int)errorCode;
@end
@interface NetworkObject : NSObject

@property (strong, nonatomic) id<NetworkDelgate> delegate;
- (void)sendRequest:(NSURLRequest *)reqObject;

@end

NS_ASSUME_NONNULL_END
