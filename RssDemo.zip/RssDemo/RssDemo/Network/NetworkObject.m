//
//  NetworkObject.m
//  RssDemo
//
//  Created by nagaranik on 12/1/19.
//  Copyright © 2019 nagaranik. All rights reserved.
//

#import "NetworkObject.h"

@implementation NetworkObject
@synthesize delegate;
- (void)sendRequest:(NSURLRequest *)reqObject
{
    NSURLSession *session=[NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration ephemeralSessionConfiguration]];
    NSURLSessionDataTask *task=[session dataTaskWithRequest:reqObject completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        if (error) {
            [self.delegate error:(int)error.code];
            return;
        }
        if ([response isKindOfClass:[NSHTTPURLResponse class]]) {
            NSInteger statusCode = [(NSHTTPURLResponse *)response statusCode];
            
            if (statusCode == 200) {
                [self.delegate sendData:data];
            }
            else
            {
                [self.delegate error:(int)error.code];
            }
        }
        
    }];
    [task resume];
}

@end
