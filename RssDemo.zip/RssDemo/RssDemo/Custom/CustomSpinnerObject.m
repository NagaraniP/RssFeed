//
//  CustomSpinnerObject.m
//  RssDemo
//
//  Created by nagaranik on 12/3/19.
//  Copyright © 2019 nagaranik. All rights reserved.
//

#import "CustomSpinnerObject.h"

@implementation CustomSpinnerObject


- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        [self addSpinner];
    }
    return self;
}


-(void)addSpinner
{
    /** Designing loadinglabel ***/
    UILabel *loadingLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 50, 170, 46)];
    loadingLabel.text = @"Loading...";
    loadingLabel.font = [UIFont systemFontOfSize:18];
    loadingLabel.textColor = [UIColor whiteColor];
    [loadingLabel setTextAlignment:NSTextAlignmentCenter];
    
     /** Designing LoadingView ***/
    contentView = [[UIView alloc]initWithFrame:CGRectMake(self.frame.size.width/2 - 100, self.frame.size.height/2 - 30, 190, 100)];
    contentView.backgroundColor = [UIColor clearColor];
    contentView.layer.cornerRadius = 10;
    contentView.layer.masksToBounds = YES;
    [self addSubview:contentView];
    /** UIActivityIndicator***/
    spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    spinner.backgroundColor = [UIColor clearColor];
    
    [contentView addSubview:loadingLabel];
    [contentView addSubview:spinner];
    
    /*** Layout Constraints ***/
    contentView.translatesAutoresizingMaskIntoConstraints = false;
    NSLayoutConstraint *loadingViewHieghtConstraint = [NSLayoutConstraint constraintWithItem:contentView attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.0 constant:100];
    NSLayoutConstraint *loadingWidthConstraint = [NSLayoutConstraint constraintWithItem:contentView attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.0 constant:190];
    
    [contentView addConstraints:@[loadingViewHieghtConstraint,loadingWidthConstraint]];
    
    NSLayoutConstraint *contentViewHorizonal = [NSLayoutConstraint constraintWithItem:contentView attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeCenterX multiplier:1.0f constant:0.0f];
    
    NSLayoutConstraint *contentViewVertical = [NSLayoutConstraint constraintWithItem:contentView attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeCenterY multiplier:1.0f constant:0.0f];
    
    [self addConstraints:@[contentViewHorizonal,contentViewVertical]];
    
    
    spinner.translatesAutoresizingMaskIntoConstraints = false;
    NSLayoutConstraint *spinnerHorizonal = [NSLayoutConstraint constraintWithItem:spinner attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:contentView attribute:NSLayoutAttributeCenterX multiplier:1.0f constant:0.0f];
    
    NSLayoutConstraint *spinnerTopConstraint = [NSLayoutConstraint constraintWithItem:spinner attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:contentView attribute:NSLayoutAttributeTop multiplier:1.0f constant:5];
    
    [contentView addConstraints:@[spinnerHorizonal,spinnerTopConstraint]];
    
    
    NSLayoutConstraint *loadinglabelHorizonal = [NSLayoutConstraint constraintWithItem:loadingLabel attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:contentView attribute:NSLayoutAttributeCenterX multiplier:1.0f constant:0.0f];
    
    NSLayoutConstraint *loadingLabelTopConstraint = [NSLayoutConstraint constraintWithItem:loadingLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:contentView attribute:NSLayoutAttributeTop multiplier:1.0f constant:50];
    
    [contentView addConstraints:@[loadinglabelHorizonal,loadingLabelTopConstraint]];
    
}
/** To show spinner***/
-(void)startSpinner
{
    [spinner startAnimating];
    [contentView setHidden:false];
    
}
/** Stop spinner ***/
-(void)stopSpinner
{
    [spinner stopAnimating];
    [contentView setHidden:true];
}
@end
