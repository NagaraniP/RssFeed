//
//  CustomSpinnerObject.h
//  RssDemo
//
//  Created by nagaranik on 12/3/19.
//  Copyright © 2019 nagaranik. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CustomSpinnerObject : UIView
{
    UIActivityIndicatorView  *spinner;
    UIView *contentView;
}
-(void)startSpinner;
-(void)stopSpinner;
@end

NS_ASSUME_NONNULL_END
