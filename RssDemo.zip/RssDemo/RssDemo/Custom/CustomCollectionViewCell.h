//
//  CustomCollectionViewCell.h
//  RssDemo
//
//  Created by nagaranik on 12/3/19.
//  Copyright © 2019 nagaranik. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CustomCollectionViewCell : UICollectionViewCell
{
    NSMutableArray *imageConstraintsArray;
    NSArray *labelCostraintsArray;
    
    NSLayoutConstraint *imageTopConstraint;
    NSLayoutConstraint *imageTrailingConstraint;
    NSLayoutConstraint *imageLeadingConstraint;
    NSLayoutConstraint *bottomConstraint;
    
    NSLayoutConstraint *titleTopConstraint;
    NSLayoutConstraint *titleTrailingConstraint;
    NSLayoutConstraint *titleLeadingConstraint;
    NSLayoutConstraint *titleHieghtConstraint;
}
@property (nonatomic, strong) UIImageView *articleImage;
@property (nonatomic, strong) UILabel *articleTitleLabel;
@end

NS_ASSUME_NONNULL_END
