//
//  CustomCollectionViewCell.m
//  RssDemo
//
//  Created by nagaranik on 12/3/19.
//  Copyright © 2019 nagaranik. All rights reserved.
//

#import "CustomCollectionViewCell.h"

@implementation CustomCollectionViewCell
@synthesize articleImage,articleTitleLabel;

-(id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        [self setTranslatesAutoresizingMaskIntoConstraints:NO];
        /*** Designing ImageView ***/
        
        articleImage = [[UIImageView alloc] initWithFrame:CGRectMake(self.frame.size.width - 5, 0, self.frame.size.width, self.frame.size.height - 55)];
         [articleImage setTranslatesAutoresizingMaskIntoConstraints:NO];
        [self addSubview:articleImage];
        
         /*** Designing UIlabel ***/
        
       articleTitleLabel = [[UILabel alloc] initWithFrame:CGRectMake(2, self.frame.size.height - 55, self.frame.size.width, 50)];
        [articleTitleLabel setTranslatesAutoresizingMaskIntoConstraints:NO];
        [articleTitleLabel setTextColor:[UIColor whiteColor]];
        articleTitleLabel.numberOfLines = 0;
        [articleTitleLabel setFont:[UIFont fontWithName:@"Arial" size:18.0f]];
        
        [self addSubview:articleTitleLabel];
     /*** ImageView Layout constraints***/
        imageTopConstraint = [NSLayoutConstraint constraintWithItem:articleImage attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeTop multiplier:1.0f constant:5];
        
        imageTrailingConstraint = [NSLayoutConstraint constraintWithItem:articleImage attribute:NSLayoutAttributeTrailing relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeTrailing multiplier:1.0f constant:0];
        
        imageLeadingConstraint = [NSLayoutConstraint constraintWithItem:articleImage attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeLeading multiplier:1.0f constant:0];
       
        bottomConstraint = [NSLayoutConstraint constraintWithItem:articleImage attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.0 constant:self.frame.size.height - 55];
        
        
        /*** Title Layout Constraints ***/
        titleTopConstraint = [NSLayoutConstraint constraintWithItem:articleTitleLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeTop multiplier:1.0f constant:self.frame.size.height - 55];
        
        titleTrailingConstraint = [NSLayoutConstraint constraintWithItem:articleTitleLabel attribute:NSLayoutAttributeTrailing relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeTrailing multiplier:1.0f constant:0];
        
        titleLeadingConstraint = [NSLayoutConstraint constraintWithItem:articleTitleLabel attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeLeading multiplier:1.0f constant:0];
        
        titleHieghtConstraint = [NSLayoutConstraint constraintWithItem:articleTitleLabel attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.0 constant:50];
        
        [self addConstraints:@[titleTopConstraint,titleTrailingConstraint,titleLeadingConstraint]];
        
        [articleTitleLabel addConstraint:titleHieghtConstraint];
        
        
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    /*** ImageView Layout Constraints ***/
   
    [self updateConstraints];
    
    [self setNeedsDisplay];
}
-(void)updateConstraints
{
    [super updateConstraints];
    /** Removing constraints and updating as per device orinetation***/
    [self removeConstraints:@[imageTopConstraint,imageTrailingConstraint,imageLeadingConstraint,bottomConstraint]];
    
    [self removeConstraints:@[titleTopConstraint,titleTrailingConstraint,titleLeadingConstraint]];
    [articleTitleLabel removeConstraint:titleHieghtConstraint];
    
    imageTopConstraint = [NSLayoutConstraint constraintWithItem:articleImage attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeTop multiplier:1.0f constant:5];
    
    imageTrailingConstraint = [NSLayoutConstraint constraintWithItem:articleImage attribute:NSLayoutAttributeTrailing relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeTrailing multiplier:1.0f constant:0];
    
    imageLeadingConstraint = [NSLayoutConstraint constraintWithItem:articleImage attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeLeading multiplier:1.0f constant:0];
    
    
    bottomConstraint = [NSLayoutConstraint constraintWithItem:articleImage attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.0 constant:self.frame.size.height - 55];
 

    [self addConstraints:@[imageTopConstraint,imageTrailingConstraint,imageLeadingConstraint,bottomConstraint]];
    
  
    
    /*** Title Layout Constraints ***/
    titleTopConstraint = [NSLayoutConstraint constraintWithItem:articleTitleLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeTop multiplier:1.0f constant:self.frame.size.height - 55];
    
    titleTrailingConstraint = [NSLayoutConstraint constraintWithItem:articleTitleLabel attribute:NSLayoutAttributeTrailing relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeTrailing multiplier:1.0f constant:0];
    
    titleLeadingConstraint = [NSLayoutConstraint constraintWithItem:articleTitleLabel attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeLeading multiplier:1.0f constant:0];
    
    titleHieghtConstraint = [NSLayoutConstraint constraintWithItem:articleTitleLabel attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.0 constant:50];
    
    [self addConstraints:@[titleTopConstraint,titleTrailingConstraint,titleLeadingConstraint]];
    
    [articleTitleLabel addConstraint:titleHieghtConstraint];
}
@end
