//
//  RssListViewModelObject.m
//  RssDemo
//
//  Created by nagaranik on 12/1/19.
//  Copyright © 2019 nagaranik. All rights reserved.
//

#import "RssListViewModelObject.h"
#import "NetworkObject.h"


static NSString *const XMLParserLink = @"link";
static NSString *const XMLParserChannel = @"channel";
static NSString *const XMLParserItem = @"item";
static NSString *const XMLParserMedia = @"media:content";
static NSString *const XMLParserURL = @"url";
static NSString *const XMLParserTitle = @"title";
static NSString *const XMLParserPubDate = @"pubDate";
static NSString *const XMLParserDescription = @"description";


@interface RssListViewModelObject ()
<NetworkDelgate,NSXMLParserDelegate>
@end
@implementation RssListViewModelObject
@synthesize listArray,feedDelegate;

- (void)sendRequestData:(NSString *)urlStr
{
    NetworkObject *netObject = [[NetworkObject alloc]init];
    [netObject setDelegate:self];
    [netObject sendRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:urlStr]]];
    
}

/** Based on responce code will pass to VC to show UI***/
-(void)error:(int)errorCode
{
    if (errorCode == -1009)
    {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.feedDelegate showAlertMessage:@"Check Internet connection\n Try again/refresh"];
        });
    }
    else{
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.feedDelegate showAlertMessage:@"Server Error!/n Please try again."];
        });
    }
    
}
/** Responce send back to VC***/
-(void)sendData:(NSData *)dataObj
{
    feeds = [[NSMutableArray alloc] init];
    parser =[[NSXMLParser alloc] initWithData:dataObj];
    parser.delegate=self;
    if([parser parse]){
        
        [self.feedDelegate sendFeeds:feeds feedTitle:feedTitle];
    }
}
/** parser dis start to know root element ***/
- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict {
    
    element = elementName;
    
    if ([element isEqualToString:XMLParserChannel])
    {
        rootElement = elementName;
        feedTitle   = [[NSMutableString alloc] init];
    }
    else if ([element isEqualToString:XMLParserItem]) {
        
        item    = [[NSMutableDictionary alloc] init];
        title   = [[NSMutableString alloc] init];
        link    = [[NSMutableString alloc] init];
        description = [[NSMutableString alloc]init];
        image = [[NSMutableString alloc]init];
        pubDate = [[NSMutableString alloc]init];
        
    }
    else if ([element isEqualToString:XMLParserMedia]) {
        image = [attributeDict objectForKey:XMLParserURL];
    }
 
}
/** Appending data between nodes***/
- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string {
    
    if([rootElement isEqualToString:XMLParserChannel])
    {
        if ([element isEqualToString:XMLParserTitle]) {
            [feedTitle appendString:string];
        }
    }
    
    if ([element isEqualToString:XMLParserTitle]) {
        [title appendString:string];
    } else if ([element isEqualToString:XMLParserLink]) {
        [link appendString:string];
    }
    else if ([element isEqualToString:XMLParserPubDate]) {
        [pubDate appendString:string];
    }
    else if ([element isEqualToString:XMLParserDescription]) {
        [description appendString:string];
    }
    
}
/*** Set values at end node***/
- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName {
    
    if([rootElement isEqualToString:XMLParserChannel])
    {
        if ([element isEqualToString:XMLParserTitle]) {
            
            rootElement = @"";
        }
    }
    else if ([elementName isEqualToString:XMLParserItem]) {
        
        [item setObject:title forKey:XMLParserTitle];
        [item setObject:link forKey:XMLParserLink];
        [item setObject:description forKey:XMLParserDescription];
        [item setObject:pubDate forKey:XMLParserPubDate];
        [item setObject:image forKey:XMLParserMedia];
        [feeds addObject:[item copy]];
        
    }
    
}

- (void)parserDidEndDocument:(NSXMLParser *)parser {
    
}

@end
