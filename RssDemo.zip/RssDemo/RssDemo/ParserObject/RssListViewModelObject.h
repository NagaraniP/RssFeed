//
//  RssListViewModelObject.h
//  RssDemo
//
//  Created by nagaranik on 12/1/19.
//  Copyright © 2019 nagaranik. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NetworkObject.h"

NS_ASSUME_NONNULL_BEGIN
@protocol FeedsDelegate <NSObject>
-(void)sendFeeds:(NSMutableArray *)array feedTitle:(NSString*)title;
-(void)showAlertMessage:(NSString*)message;
@end
@interface RssListViewModelObject : NSObject
{
    NSXMLParser *parser;
    NSMutableArray *feeds;
    NSMutableDictionary *item;
    NSMutableString *title;
    NSMutableString *link;
    NSMutableString *pubDate;
    NSMutableString *image;
    NSMutableString *description;
    NSString *element;
    NSString *rootElement;
    NSMutableString *currentElement;
    NSMutableString *feedTitle;
    
}
@property (weak, nonatomic) id<FeedsDelegate> feedDelegate;
- (void)sendRequestData:(NSString *)urlStr;
@property(nonatomic,weak)NSMutableArray *listArray;
@end

NS_ASSUME_NONNULL_END
