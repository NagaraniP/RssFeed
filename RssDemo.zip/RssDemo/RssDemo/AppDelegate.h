//
//  AppDelegate.h
//  RssDemo
//
//  Created by nagaranik on 12/1/19.
//  Copyright © 2019 nagaranik. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

